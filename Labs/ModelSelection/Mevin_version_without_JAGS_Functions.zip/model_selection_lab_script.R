####
####  Load Packages
####

library(rjags)

####
####  Load Data 
####

bird.df<- read.csv("birds.csv")
head(bird.df)

####
####  Remove Outliers 
####

idx.outlier=(1:51)[(bird.df$spp==min(bird.df$spp) | bird.df$area==max(bird.df$area))]
bird.sm.df=bird.df[-idx.outlier,]

####
####  Setup Data to Fit Model 
####

#X = model.matrix(~1, data = bird.sm.df)
#X = model.matrix(~as.numeric(scale(area)), data = bird.sm.df)
#X = model.matrix(~as.numeric(scale(temp)), data = bird.sm.df)
#X = model.matrix(~as.numeric(scale(precip)), data = bird.sm.df)
X = model.matrix(~as.numeric(scale(area)) + as.numeric(scale(temp)), data = bird.sm.df)
y = bird.sm.df$spp  
M1.list <- list(y=y,X=as.matrix(X),n=length(y),p=dim(X)[2])

####
####  Fit Model Using JAGS 
####

inits=list(beta=c(mean(log(y)),rep(0,dim(X)[2]-1)))
M1.model <- jags.model("pois.reg.R",data=M1.list,inits=inits,n.chains=2,n.adapt=1000)
M1.out.mat=as.matrix(M1.out)
update(M1.model,n.iter=1000)
M1.out <- coda.samples(M1.model,variable.names=c("beta","lambda"),n.iter=8000)
summary(M1.out)
mean.beta = apply(M1.out.mat[,1:dim(X)[2]],2,mean)

###
###Run these inits, M1.model, and mean commands for null model only
###
#inits=list(beta=c(mean(log(y)))) # uncomment for the null model
#M1.model <- jags.model("pois.reg.0.R",data=M1.list,inits=inits,n.chains=2,n.adapt=1000)
#update(M1.model,n.iter=1000)
#M1.out <- coda.samples(M1.model,variable.names=c("beta","lambda"),n.iter=8000)
#summary(M1.out)
#M1.out.mat=as.matrix(M1.out)
#mean.beta = mean(M1.out.mat[,1:dim(X)[2]])


####
####  Calculate DIC from JAGS Output 
####

lambda=M1.out.mat[,-(1:dim(X)[2])]
mean.lambda = apply(lambda,2,mean)
Dhat = -2*(sum(dpois(y,mean.lambda,log=TRUE))) 
Dbar = mean(-2*apply(dpois(y,t(lambda),log=TRUE),2,sum))
pD.DIC = Dbar - Dhat
DIC = Dhat + 2*pD.DIC
c(pD.DIC,DIC)

####
####  Calculate WAIC from JAGS Output 
####

lppd=-2*sum(log(apply(dpois(y,t(lambda)),1,mean)))
pD.WAIC=sum(apply(dpois(y,t(lambda),log=TRUE),1,var))
WAIC=lppd+2*pD.WAIC
c(pD.WAIC,WAIC)

####
####  Calculate D_inf from JAGS Output 
####

y.pred=matrix(0,length(y),8000)
for(k in 1:8000){
  y.pred[,k]=rpois(length(y),lambda[k,])
}  

D.inf=sum((y-apply(y.pred,1,mean))^2)+sum(apply(y.pred,1,var))
D.inf

####
#### Calculate DIC using Built-in JAGS Function 
####
#### This needs multiple chains to work.
####

DIC.jags=dic.samples(M1.model,n.iter=8000,type="pD")
DIC.jags


