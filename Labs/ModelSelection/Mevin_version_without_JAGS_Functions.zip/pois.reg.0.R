model {

  # LIKELIHOOD
  # n= number of states
  # y = number of birds in each state

  for(i in 1:n)   { 
      y[i] ~ dpois(lambda[i])
      lambda[i] <- exp(z[i])
  }
  z <- X %*% beta

  # PRIORS
  # p = number of coefficients, including intercept

  for(i in 1:p) {  
    beta[i] ~ dnorm(0, 0.01)
  }

}
