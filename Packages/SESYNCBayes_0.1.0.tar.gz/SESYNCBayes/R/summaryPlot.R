#' @title Summary Plot of 95\% Confidence Intervals
#'
#' @description Creates a concise plot showing Bayesian 95\% confidence intervals and median values for selected parameters from a coda sample object.
#' @param samplesObject name of coda sample object
#' @param cols a numeric vector specifying the columns from the samplesObject to plot
#' @param xlab x-axis label (default is NULL)
#' @param ylab yaxis label (default is NULL)
#' @param label a charcter vector specifying the labels for the chosen parameters in col (default is cols vector)
#' @param xrange numeric vector specfiying the x-axis range (default = c(-1,1))
#' @param vline value specifying the vertical line drawn on the plot (default = 0)
#' @param cex (default = .75)
#' @param col (default = "black")
#' @export
#' @return NULL
summaryPlot <- function(samplesObject, cols, xlab = NULL, ylab =NULL, label = cols, xrange = c(-1,1), vline = 0, cex = .75, col = "black"){
  par(mar=c(5, 5, 1, 1))
  plotData <- summary(samplesObject[,cols])[[2]]
  plot(x=xrange, y=c(1,length(cols)), type="n", xlab = xlab, ylab = ylab, axes = FALSE, cex.lab = cex, cex.axis = cex)
  axis(1, cex.lab = cex, cex.axis = cex)
  axis(2, at = length(cols):1, labels = label, padj = 0.5, las = 1, cex.lab = cex, cex.axis = cex)
  segments(x0 = plotData[,1], x1 = plotData[,5], y0 = length(cols):1, y1 = length(cols):1, col = col)
  segments(x0 = plotData[,2], x1 = plotData[,4], y0 = length(cols):1, y1 = length(cols):1, lwd = 3, col = col)
  abline(v = vline, col = "gray")
  points(plotData[,3], length(cols):1, col = col)
  invisible()
}
